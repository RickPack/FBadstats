library(testthat)
library(FBadstats)
test_check("FBadstats")
